# springcloud

## 配置中心如何替换配置文件中的占位符